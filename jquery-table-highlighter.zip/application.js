$(document).ready(function() {
	$('#page').tablehighlight();
});